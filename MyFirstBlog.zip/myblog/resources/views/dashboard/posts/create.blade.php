@extends('layouts.app')

@section('content')

    <div class="container" style="margin-top: 20px;">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Create Post') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        <form action="/post/add" method="post">
                            @csrf
                            <div class="form-group">
                                <label for="">Post Title</label>
                                <input type="text" class="form-control" name="title" value="{{ old('title')}}" class="form-control">
                                <span class="text-danger">@error('title'){{$message}} @enderror</span>
                            </div>

                            <div class="form-group">
                                <label for="">Post Body</label>
                                <textarea name="body" value="{{old('body')}}" class="form-control" cols="30" rows="10" class="form-control"></textarea>
                                <span class="text-danger">@error('body'){{$message}} @enderror</span>
                            </div>

                            <button type="submit" style="margin-top: 10px;" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

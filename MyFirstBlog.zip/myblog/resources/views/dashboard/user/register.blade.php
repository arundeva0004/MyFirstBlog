@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA compatible" content="ie=edge">
    <title> Register</title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-4 offset-md-4" style="margin-top: 45px;">
            <h4>Register</h4>
            <form action="{{route('.create')}}" method="post" autocomplete="off">
                @if(Session::get('success'))
                    <div class="alert alert-success">
                        {{session::get('success')}}
                    </div>
                @endif
                @if(Session::get('fail'))
                    <div class="alert alert-danger">
                        {{session::get('fail')}}
                    </div>
                @endif
                @csrf
                <div class="form-group">
                    <label for="name"> Name</label>
                    <input type="text" class="form-control" name="name" value="{{ old('name')}}" placeholder="Name">
                    <span class="text-danger">@error('name'){{$message}} @enderror</span>
                </div>
                <div class="form-group">
                    <label for="email"> Email</label>
                    <input type="text" class="form-control" name="email" value="{{ old('email')}}" placeholder="Email Address">
                    <span class="text-danger">@error('email'){{$message}} @enderror</span>
                </div>
                <div class="form-group">
                    <label for="role"> Role</label>
                    <select class="form-control" name="role_id">
                        <option value="2" selected="selected">Blogger</option>
                        <option value="3">User</option>
                    </select>
                    <span class="text-danger">@error('role_id'){{$message}} @enderror</span>
                </div>
                <div class="form-group">
                    <label for="password"> Password</label>
                    <input type="password" class="form-control" name="password" value="{{ old('password')}}" placeholder="Password">
                    <span class="text-danger">@error('password'){{$message}} @enderror</span>
                </div>
                <div class="form-group">
                    <label for="cpassword"> Confirm Password</label>
                    <input type="password" class="form-control" name="cpassword" value="{{ old('cpassword')}}" placeholder="Confirm Password">
                    <span class="text-danger">@error('cpassword'){{$message}} @enderror</span>
                </div>
                <div class="form-group col-md-8" style="margin: 25px 80px;">
                    <button type="submit" class="btn btn-outline-success col-md-8"> Register </button>
                </div>
                <div class="form-group col-md-8" style="margin: 0px 80px;">
                    <a href="{{route('.login')}}" class="btn btn-outline-primary col-md-8"> I have an account </a>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>

@endsection

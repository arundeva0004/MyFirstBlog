@extends('layouts.app')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-12 pt-2">
                <div class="row">
                    <div class="col-8">
                        <h1 class="display-one">Welcome to our blog {{Auth::user()->name}} !</h1>
                        <p>Enjoy reading our posts!</p>
                    </div>
                    <div class="col-4">
                        <p>Create new Post</p>
                        <a href="/post/create" class="btn btn-primary btn-sm">Add Post</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Created at</th>
                        <th colspan="2">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($posts as $post)
                        <tr>
                            <td>{{ $post->id }}</td>
                            <td>{{ $post->title }}</td>
                            <td>{{ date('Y-m-d', strtotime($post->created_at)) }}</td>
                            <td>
                                <a href="post/{{$post->id}}" class="btn btn-primary">View</a>

                                @if(Auth::user()->role_id !== 3 )
                                    <a href="post/{{$post->id}}/edit" class="btn btn-primary">Edit</a>
                                @endif
                                @if(Auth::user()->role_id === 1 )
                                <form action="post/{{$post->id}}" method="post" class="d-inline">
                                    {{ csrf_field() }}
                                    @method('DELETE')
                                    <button class="btn btn-danger"
                                            type="submit">Delete</button>
                                </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

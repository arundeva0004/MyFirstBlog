<?php

namespace App\Http\Controllers\Post;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Post;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{

    public function add(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'body' => 'required',
        ]);
        $post = new Post();
        $post->title = $request->title;
        $post->body = $request->body;
        $post->created_by = Auth::user()->id;


        $post->save();
        return redirect('/home');
    }

    public function show(Post $post)
    {
        return view('dashboard.posts.show', compact('post'));
    }

    public function edit(Post $post)
    {
        return view('dashboard.posts.edit', compact('post'));
    }

    public function update(Post $post, Request $request, $id)
    {

        $request->validate([
            'title' => 'required',
            'body' => 'required',
        ]);

        $post = Post::where('id',$id)
            ->update(['title'=> $request->title,
                'body' => $request->body]);

        return redirect('/home');
    }

    public function destroy(Post $post)
    {
        $post->delete();
        return redirect('/home');
    }
}

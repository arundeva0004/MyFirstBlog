<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-12 pt-2">
                <div class="row">
                    <div class="col-8">
                        <h1 class="display-one">Welcome to our blog <?php echo e(Auth::user()->name); ?> !</h1>
                        <p>Enjoy reading our posts!</p>
                    </div>
                    <div class="col-4">
                        <p>Create new Post</p>
                        <a href="/post/create" class="btn btn-primary btn-sm">Add Post</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Created at</th>
                        <th colspan="2">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($post->id); ?></td>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e(date('Y-m-d', strtotime($post->created_at))); ?></td>
                            <td>
                                <a href="post/<?php echo e($post->id); ?>" class="btn btn-primary">View</a>

                                <?php if(Auth::user()->role_id !== 3 ): ?>
                                    <a href="post/<?php echo e($post->id); ?>/edit" class="btn btn-primary">Edit</a>
                                <?php endif; ?>
                                <?php if(Auth::user()->role_id === 1 ): ?>
                                <form action="post/<?php echo e($post->id); ?>" method="post" class="d-inline">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger"
                                            type="submit">Delete</button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\myblog\myblog\resources\views/dashboard/user/home.blade.php ENDPATH**/ ?>